/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//23-09-24
#include <stdio.h>

int main()
{
    int n,i=1,sum=0,rem;
    printf("enter a number");
    scanf("%d",&n);
 
    while(n>0){
        rem=n%2;
        n=n/2;
        sum=sum+rem*i;
        i=i*10;
        
    }
    printf("binary number is:%d",sum);
    return 0;
}
